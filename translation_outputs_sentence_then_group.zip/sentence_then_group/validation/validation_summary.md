# Translation validation summary

Mode: `sentence_then_group` | model `ai4bharat/indictrans2-indic-en-dist-200M` | device `cpu` | beams 4 | use_cache=False

## Integrity
- checks run: 49; failed: 0
- sentences: 374; paragraphs: 78

## Quality flags (heuristic)
- units needing review (hard flags): 6; units with any flag: 17

| file | sentences | paragraphs | hard-flagged | flag counts |
|---|---|---|---|---|
| sample-1.txt | 49 | 10 | 0 | {'null_count_mismatch': 1} |
| sample-2.txt | 51 | 11 | 0 | {} |
| sample-3.txt | 48 | 10 | 1 | {'number_missing': 1} |
| sample-4.txt | 58 | 12 | 3 | {'number_missing': 3, 'null_count_mismatch': 1} |
| sample-5.txt | 56 | 12 | 2 | {'null_count_mismatch': 3, 'number_missing': 2} |
| sample-6.txt | 52 | 11 | 0 | {'null_count_mismatch': 1} |
| sample-7.txt | 60 | 12 | 0 | {'length_ratio': 1, 'null_count_mismatch': 3, 'no_terminal_punct': 1} |

## Hard-flagged units
- sample-3.txt #15: ['number_missing:4'] :: In Hastinapur, Adinath Bhagwan came on the day of Vaishakh Shukla Tritiya, 400 days after taking dik
- sample-4.txt #0: ['number_missing:80'] :: India has the highest area under cotton cultivation in the world at about 8 million hectares.
- sample-4.txt #6: ['number_missing:4,5'] :: More than 45 million people are employed in cotton cultivation and earn a living from it.
- sample-4.txt #54: ['number_missing:50,000'] :: It is a small-scale industry, with 50,000 villages engaged in sericulture.
- sample-5.txt #35: ['number_missing:12'] :: It would be more appropriate to say that he writes the eight digits with silk thread about 1.2 milli
- sample-5.txt #38: ['number_missing:40,000'] :: About 40,000 eggs weigh only about an ounce.

## Caveats
- Passing integrity checks means every sentence was translated, counted and written consistently. It does NOT measure translation quality.
- Number check covers digits only (not number words). Untranslated-Hindi check looks for Devanagari characters in the output.
- Length-ratio, terminal-punctuation, repetition and sentence-count flags are heuristics and can fire on correct output.
- No reference translations exist, so no BLEU/chrF/COMET is reported. Read the flagged units and spot-check the rest.
- Sentence-then-group is a methodological variant of 'translate groups of five'; its advantage was seen qualitatively on one railway passage only.

## Methodology
Assignment wording: translate groups of five sentences. Default here: translate each sentence, then group five translations (final incomplete group kept). Strict alternative: set CFG['mode']='paragraph_level' and re-run T2-T10.
